#!/system/bin/sh
if ! applypatch -c MTD:recovery:2048:37ce9459496e394dbfb3ab0b8cf86829c0fb70e6; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:2392064:a233aa76b83a5efcc03f66c51a418cb15c4d9ab2 MTD:recovery eaa0b1ada9c064af247346e14e76339f61866b2e 2623488 a233aa76b83a5efcc03f66c51a418cb15c4d9ab2:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
